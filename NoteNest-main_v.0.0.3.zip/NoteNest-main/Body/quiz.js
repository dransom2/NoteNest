//TODO Replace console.log(s) with appropriate file type, and location(s)

//Class containing the quizmaking/reading/writing funcitons
const Quiz = (() => {
  let quizzes = {};        // stores quizzes by name
  let currentQuiz = null;  // current quiz
  let currentIndex = 0;    // question index
  let score = 0;           // user score


  //Loading, Creating, and Starting a Quiz funtions
  function createQuiz(name, questions) {
    quizzes[name] = {
      name,
      questions,
      created: new Date().toISOString() //toISOString is just the universal formatting for time/date, allowing anything using .ISO to read the data. Could be helpful in the long run
    };
    saveToStorage();
    console.log(`Quiz "${name}" created successfully.`);
  }
//LoadQuiz sets the score and Index to = 0, important for taking multiple test
function loadQuiz(name) {
    const stored = loadFromStorage();
    if (!stored[name]) throw new Error(`Quiz "${name}" not found.`);  // 'throw new Error' will display the following text in the case of not finding the name
    currentQuiz = stored[name];
    currentIndex = 0;
    score = 0;
    console.log(`Loaded quiz: ${name}`);
    return currentQuiz;
  }

  function startQuiz(name) {
      loadQuiz(name); //found at line 19
      showQuestion(); //found at line 38
    }


  //
  function showQuestion() {
    const q = currentQuiz.questions[currentIndex];
  // if there are no more questions, this loop should run, ending the quiz
    if (!q) {
      endQuiz();
      return;
    }
    
    currentIndex++;

  if (currentIndex < currentQuiz.questions.length) {
    showQuestion();
    } else {
      endQuiz();
    }
  }

  function submitAnswer(answerIndex) {
    const q = currentQuiz.questions[currentIndex];
    if (q.correct === answerIndex) {
      score++;
      console.log("✅ Correct!");
    } else {
      console.log("❌ Incorrect.");
    }
  }

  function endQuiz() {
    console.log("🎉 Quiz completed!");
    console.log(`Your score: ${score}/${currentQuiz.questions.length}`);
  }

  return {
    createQuiz,
    startQuiz,
    submitAnswer,
    loadFromStorage
  };
})()