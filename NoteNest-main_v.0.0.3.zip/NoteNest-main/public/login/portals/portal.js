// public/login/portals/portal.js
import { auth, db } from "../../main/firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.12.0/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/11.12.0/firebase-firestore.js";

const userDisplay = document.getElementById("userDisplay");
const logoutBtn = document.getElementById("logoutBtn");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    // not logged in equals back to login page
    window.location.href = "/login/login.html";
    return;
  }
  //DEV_CODE: show user email/name
 //userDisplay.textContent = user.displayName || user.email;

  try {
    const snap = await getDoc(doc(db, "users", user.uid));
    const role = snap.exists() ? snap.data().role : "student";

    // if page is admin-only and role isn't admin this will redirect
    if (location.pathname.endsWith("admin.html") && role !== "admin" && role !== "teacher") {
      window.location.href = "/login/portals/student.html"; //TODO: See if we can fetch last page instead of sending them to login/home.
    }
  } catch (err) {
    console.error("failed to load user metadata", err);
  }
});

logoutBtn?.addEventListener("click", async () => {
  await signOut(auth);
  window.location.href = "/login/login.html";
});
