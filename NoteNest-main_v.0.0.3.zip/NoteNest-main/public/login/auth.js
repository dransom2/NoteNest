import { auth, db } from "../main/firebase.js";
import { signInWithEmailAndPassword, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";
import { doc, getDoc }
  from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js";

const form = document.getElementById("loginForm");
const msg = document.getElementById("message");

//Login
onAuthStateChanged(auth, (user) => {
  if (user) console.log("🔐 Already logged in:", user.email);

});
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "";

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    const uid = cred.user.uid;
    console.log("✅ Signed in as", cred.user.email);

    let role = "student";
    try {
      const snap = await getDoc(doc(db, "users", uid));
      if (snap.exists()) role = snap.data().role || "student";
    } catch (err) {
      console.warn("⚠️ Firestore lookup failed:", err);
    }

    if (role === "admin" || role === "teacher") {
      window.location.href = "../portals/admin.html";
    } else {
      window.location.href = "../portals/student.html";
    }
  } catch (err) {
    console.error("❌ Login error:", err);
    msg.textContent = err.message || "Login failed.";
  }
});


