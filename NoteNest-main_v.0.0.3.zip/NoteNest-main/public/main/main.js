
import { validateEmail, getUser, setUser, clearUser } from "../Body/auth.js";
import { initQuiz, answerQuestion, summarizeQuiz } from "../Body/quiz.js";
import { saveResult, getResult } from "../Body/results.js";
import { login, logout } from "../login/auth.js";
import { startQuiz, answer, finish } from "../controllers/quiz.js";

// Redirects to login.html if not signed in at any point (keep at top)
const auth = JSON.parse(localStorage.getItem("notenest.auth") || "{}");
if (!auth.isAuthenticated) {
  window.location.href = "../login/login.html";
}
