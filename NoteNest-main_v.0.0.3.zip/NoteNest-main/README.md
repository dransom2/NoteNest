# NoteNest
NoteNest is a simple, web-based study tool that helps students organize notes and turn them into digital flashcards. It’s designed to make studying easier, more interactive, and accessible anywhere, keeping all learning materials in one neat and organized place.

ADDED:
Login feature using Firebase, (use "devuser@twu.edu  &  dev0nly" for a temp student login ||  "dransom2@twu.edu  &  123456" for admin login),
extracted login functions from test.html and injected into login.html
redirects from login to temporary admin or student pages respectively

TODO: Add logout feature,
 add sign up feature (ask if student or teacher login),
 divide the rest of 'test.html' into seperate .html files for readability,
 convert .txt to .JSON for server side storage,
 and more..